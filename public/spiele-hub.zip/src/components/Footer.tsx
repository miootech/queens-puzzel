'use client';

import { motion } from 'framer-motion';
import { Instagram, Globe, Heart } from 'lucide-react';

export function Footer() {
  return (
    <footer className="mt-16 flex w-full max-w-3xl flex-col items-center gap-3 px-6 pb-8 pt-4">
      {/* Social Icons */}
      <div className="flex items-center gap-4">
        <motion.a
          href="https://instagram.com/malikali065"
          target="_blank"
          rel="noopener noreferrer"
          whileHover={{ scale: 1.08, y: -2 }}
          whileTap={{ scale: 0.95 }}
          className="group relative flex h-11 w-11 items-center justify-center rounded-full ring-1 ring-white/10 transition-all hover:ring-white/20"
          aria-label="Instagram: @malikali065"
        >
          <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-yellow-400 via-pink-500 to-purple-600 opacity-90 transition-opacity group-hover:opacity-100" />
          <Instagram className="relative h-[18px] w-[18px] text-white" strokeWidth={2.2} />
        </motion.a>

        <motion.a
          href="https://arche-website.pages.dev"
          target="_blank"
          rel="noopener noreferrer"
          whileHover={{ scale: 1.08, y: -2 }}
          whileTap={{ scale: 0.95 }}
          className="group relative flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-sky-500 to-cyan-600 ring-1 ring-white/10 transition-all hover:ring-white/20"
          aria-label="Website: arche-website.pages.dev"
        >
          <Globe className="h-[18px] w-[18px] text-white" strokeWidth={2.2} />
        </motion.a>
      </div>

      {/* Handles */}
      <div className="flex flex-col items-center gap-0.5 text-center">
        <a
          href="https://instagram.com/malikali065"
          target="_blank"
          rel="noopener noreferrer"
          className="text-[12px] font-medium text-neutral-300 transition-colors hover:text-white"
        >
          @malikali065
        </a>
        <a
          href="https://arche-website.pages.dev"
          target="_blank"
          rel="noopener noreferrer"
          className="text-[11px] text-neutral-500 transition-colors hover:text-neutral-300"
        >
          arche-website.pages.dev
        </a>
      </div>

      {/* Credit line */}
      <div className="flex items-center gap-1.5 text-[11px] text-neutral-500">
        <span>Entwickelt mit</span>
        <Heart className="h-3 w-3 fill-red-500 text-red-500" />
        <span>von Ali Malik</span>
      </div>

      {/* Copyright */}
      <div className="text-[10px] font-medium uppercase tracking-[0.18em] text-neutral-700">
        © 2026 Ali Malik · All Rights Reserved
      </div>
    </footer>
  );
}
