import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Spiele Hub — Rätsel & Logik",
  description: "Eine kuratierte Sammlung von Rätseln und Logik-Spielen im Apple-Style.",
  keywords: ["Spiele", "Rätsel", "Puzzle", "Queens", "Strands"],
  authors: [{ name: "Ali Malik" }],
  openGraph: {
    title: "Spiele Hub",
    description: "Eine kuratierte Sammlung von Rätseln und Logik-Spielen.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="de" suppressHydrationWarning>
      <body className="antialiased">
        {children}
      </body>
    </html>
  );
}
