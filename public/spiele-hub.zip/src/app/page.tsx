'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Footer } from '@/components/Footer';

interface Game {
  name: string;
  image: string;
  link: string;
}

interface GamesData {
  games: Game[];
}

export default function HubPage() {
  const [data, setData] = useState<GamesData | null>(null);

  useEffect(() => {
    fetch('/games.json')
      .then(res => res.json())
      .then(setData)
      .catch(() => setData({ games: [] }));
  }, []);

  return (
    <div className="bg-mesh relative flex min-h-screen w-full flex-col items-center px-5 py-10 sm:px-8 sm:py-14">
      <div className="flex w-full max-w-5xl flex-1 flex-col items-center gap-12">
        {/* Hero */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col items-center gap-3 text-center"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.25, duration: 0.6 }}
            className="flex items-center gap-2 rounded-full bg-white/[0.03] px-3.5 py-1.5 ring-1 ring-white/[0.06]"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-[var(--word-gold)] shadow-[0_0_8px_var(--word-gold)]" />
            <span className="text-[10px] font-medium uppercase tracking-[0.22em] text-neutral-400">
              Spiele
            </span>
          </motion.div>

          <h1
            className="text-[48px] font-bold leading-none tracking-tight text-neutral-50 sm:text-[72px]"
            style={{ fontFamily: 'Georgia, "Times New Roman", serif', letterSpacing: '-0.03em' }}
          >
            Spiele
          </h1>
        </motion.div>

        {/* Grid — 1 col mobile, 2 col tablet, 3 col desktop */}
        <div className="grid w-full grid-cols-1 gap-x-5 gap-y-7 sm:grid-cols-2 sm:gap-x-6 sm:gap-y-8 lg:grid-cols-3 lg:gap-x-7 lg:gap-y-10">
          {data?.games.map((game, idx) => (
            <GameCard key={game.name} game={game} index={idx} />
          ))}
        </div>

        {/* Empty state */}
        {data && data.games.length === 0 && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-[14px] font-light text-neutral-500"
          >
            Noch keine Spiele. Füge welche zu public/games.json hinzu.
          </motion.p>
        )}
      </div>

      <Footer />
    </div>
  );
}

// ─── Game Card ───
// 16:10 Bild-Card als eigenständiges rounded rectangle
// Name als separater Pill darunter mit Abstand
function GameCard({ game, index }: { game: Game; index: number }) {
  return (
    <motion.a
      href={game.link}
      target="_blank"
      rel="noopener noreferrer"
      initial={{ opacity: 0, y: 16, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{
        delay: 0.3 + index * 0.08,
        duration: 0.5,
        ease: [0.16, 1, 0.3, 1],
      }}
      whileHover={{ y: -4 }}
      className="group flex flex-col items-center"
    >
      {/* Bild-Card — 16:10, eigenständiges rounded rectangle */}
      <motion.div
        whileHover={{ scale: 1.03 }}
        transition={{ type: 'spring', stiffness: 400, damping: 25 }}
        className="relative aspect-[16/10] w-full overflow-hidden rounded-2xl bg-white/[0.04] ring-1 ring-white/[0.06] transition-shadow group-hover:ring-white/[0.12] group-hover:shadow-[0_12px_40px_rgba(0,0,0,0.4)]"
      >
        <img
          src={game.image}
          alt={game.name}
          className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
          onError={(e) => {
            (e.target as HTMLImageElement).style.display = 'none';
          }}
        />
      </motion.div>

      {/* Name-Pill — separates Element mit Abstand zum Bild */}
      <div className="mt-3.5 flex items-center gap-2 rounded-full bg-white/[0.06] px-5 py-2 ring-1 ring-white/[0.08] backdrop-blur-sm transition-colors group-hover:bg-white/[0.1] group-hover:ring-white/[0.14]">
        <h2
          className="text-[14px] font-semibold tracking-tight text-neutral-50 sm:text-[15px]"
          style={{ fontFamily: 'Georgia, "Times New Roman", serif', letterSpacing: '-0.01em' }}
        >
          {game.name}
        </h2>
        <span className="text-[12px] text-neutral-500 transition-all group-hover:translate-x-0.5 group-hover:text-neutral-300">
          →
        </span>
      </div>
    </motion.a>
  );
}
